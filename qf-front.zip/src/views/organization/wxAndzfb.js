//微信和支付宝通道的id
export const WeiXinId = '74e1479029544232a218a3e60cb791fc';
export const ZhiFuBaoId = '0c811cd8f6a3453da7eca6e446a54528';