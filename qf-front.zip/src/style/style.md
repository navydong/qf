
##### 上部搜索框
- card 
    - ` bordered={false} bodyStyle={{backgroundColor: "#f8f8f8"}}  noHovering`
- 查询按钮  
    - `className="btn-search"`   
    - `type="primary"`
- 重置按钮  
     - `className="btn-reset"`
- 整个搜索框组件要加类名
    - `search-box`
##### 下部表格
- card
    - `bordered={false} noHovering bodyStyle={{paddingLeft: 0}}`
- 去掉按钮组
- 按钮所在Col样式
     - `style={{marginLeft:14}}`
- 增加按钮
    - `className="btn-add"`
    - `size="large"`
    - `shape="circle"`
    - `type="primary"`
    - `icon="plus"`
- 删除按钮
    - `className="btn-delete"`
    - `type="primary"`
    - `size="large"`
    - `shape="circle"`
    - `icon="delete"`
- table
    - `bordered={false}`



### 未完成
- 侧边导航一级菜单下面加线