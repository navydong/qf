module.exports = {
    entry: {
        vendor: ['antd'],    // 需要分离的库
        charts: ['echarts-for-react']
    }
};